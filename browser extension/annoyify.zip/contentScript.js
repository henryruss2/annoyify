//main function, does everything
var annoy = function() {
var all =  document.querySelectorAll(html);
all.style.color = "green";
all.style.backgroundColor = "LightGreen"
};
